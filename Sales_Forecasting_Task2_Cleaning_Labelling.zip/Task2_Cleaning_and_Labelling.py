# Task 2: Data Cleaning and Labelling
# Project: Sales Forecasting and Trend Analysis Using Time-Series Models
# Dataset: Retail Sales Dataset (CSV downloaded from the source selected for the project)

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Put the downloaded dataset CSV in the same folder as this Python file.
INPUT_FILE = "retail_sales_dataset.csv"
OUTPUT_FILE = "sales_cleaned_labelled.csv"

# 1. Load the data
df = pd.read_csv(INPUT_FILE)
print("Original dataset shape:", df.shape)
print("\nMissing values before cleaning:\n", df.isnull().sum())

# 2. Clean column names and remove duplicate records
df.columns = [str(col).strip().replace(" ", "_") for col in df.columns]
df = df.drop_duplicates().copy()

# 3. Identify date and sales columns (handles common Retail Sales Dataset names)
date_candidates = ["Date", "date", "Order_Date", "Sales_Date", "Transaction_Date"]
date_col = next((c for c in date_candidates if c in df.columns), None)
if date_col is None:
    raise ValueError("Date column not found. Check the dataset's date column name.")

df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
df = df.dropna(subset=[date_col]).copy()

# Convert common numeric fields when present
numeric_candidates = [
    "Quantity", "Price_per_Unit", "Price_per_unit",
    "Total_Amount", "Sales", "Revenue", "Amount"
]
for col in numeric_candidates:
    if col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

# Create/standardize a sales value column
sales_candidates = ["Total_Amount", "Sales", "Revenue", "Amount"]
sales_col = next((c for c in sales_candidates if c in df.columns), None)

if sales_col is None and {"Quantity", "Price_per_Unit"}.issubset(df.columns):
    df["Total_Sales"] = df["Quantity"] * df["Price_per_Unit"]
    sales_col = "Total_Sales"
elif sales_col is None and {"Quantity", "Price_per_unit"}.issubset(df.columns):
    df["Total_Sales"] = df["Quantity"] * df["Price_per_unit"]
    sales_col = "Total_Sales"

if sales_col is None:
    raise ValueError(
        "Sales column not found. Expected Total_Amount, Sales, Revenue, Amount, "
        "or both Quantity and Price_per_Unit."
    )

# Remove rows with missing or impossible sales values
df = df.dropna(subset=[sales_col]).copy()
df = df[df[sales_col] >= 0].copy()

# Remove invalid quantities/prices if these columns exist
for col in ["Quantity", "Price_per_Unit", "Price_per_unit"]:
    if col in df.columns:
        df = df[df[col].isna() | (df[col] >= 0)].copy()

# Fill missing categorical labels with an explicit category
for col in df.select_dtypes(include=["object", "string"]).columns:
    df[col] = df[col].fillna("Unknown").astype(str).str.strip()
    df.loc[df[col].eq(""), col] = "Unknown"

# 4. Add time-based labels for trend analysis
df["Year"] = df[date_col].dt.year
df["Month"] = df[date_col].dt.month
df["Month_Name"] = df[date_col].dt.month_name()
df["Quarter"] = "Q" + df[date_col].dt.quarter.astype(str)
df["Year_Month"] = df[date_col].dt.to_period("M").astype(str)
df["Weekday"] = df[date_col].dt.day_name()

# Add sales-level labels using quantiles, which adapt to the dataset
q_low = df[sales_col].quantile(0.33)
q_high = df[sales_col].quantile(0.66)
df["Sales_Level"] = np.select(
    [df[sales_col] <= q_low, df[sales_col] <= q_high],
    ["Low", "Medium"],
    default="High"
)

# Sort chronologically for time-series work
df = df.sort_values(date_col).reset_index(drop=True)

# 5. Save cleaned and labelled transaction-level data
df.to_csv(OUTPUT_FILE, index=False)
print("\nCleaned dataset shape:", df.shape)
print("Saved cleaned data to:", OUTPUT_FILE)
print("\nMissing values after cleaning:\n", df.isnull().sum())

# 6. Prepare monthly sales data for forecasting
monthly_sales = (
    df.set_index(date_col)[sales_col]
      .resample("MS")
      .sum()
      .reset_index()
)
monthly_sales.columns = ["Date", "Monthly_Sales"]
monthly_sales["Year_Month"] = monthly_sales["Date"].dt.to_period("M").astype(str)
monthly_sales.to_csv("monthly_sales_for_forecasting.csv", index=False)

# 7. Save a simple monthly sales trend graph
plt.figure(figsize=(10, 5))
plt.plot(monthly_sales["Date"], monthly_sales["Monthly_Sales"], marker="o")
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("monthly_sales_trend.png", dpi=150)
plt.show()

print("\nMonthly sales data saved to monthly_sales_for_forecasting.csv")
print("Trend graph saved to monthly_sales_trend.png")
