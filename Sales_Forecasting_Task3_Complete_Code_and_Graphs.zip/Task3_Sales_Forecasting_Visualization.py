# Task 3: Sales Forecasting and Trend Analysis Using Time-Series Models
# This script creates visualizations and a 6-month sales forecast.
#
# To use your real data:
# 1. Put your downloaded CSV in this folder and name it retail_sales_dataset.csv.
# 2. Run this script. If that file is not found, the included demo CSV is used.
# 3. Demo data is only for testing; use your actual dataset for final results.

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

INPUT_FILE = "retail_sales_dataset.csv"
DEMO_FILE = "demo_retail_sales_dataset.csv"
OUTPUT_DIR = "task3_outputs"
FORECAST_MONTHS = 6

os.makedirs(OUTPUT_DIR, exist_ok=True)

# -------------------- 1. Load data --------------------
if os.path.exists(INPUT_FILE):
    df = pd.read_csv(INPUT_FILE)
    print(f"Using your dataset: {INPUT_FILE}")
elif os.path.exists(DEMO_FILE):
    df = pd.read_csv(DEMO_FILE)
    print(f"'{INPUT_FILE}' was not found. Using the included DEMO dataset.")
    print("Replace the demo with your actual dataset before final submission.")
else:
    raise FileNotFoundError(
        "Place your CSV in this folder as retail_sales_dataset.csv."
    )

# Standardize column names
df.columns = [str(c).strip().replace(" ", "_") for c in df.columns]

# Find date column
date_candidates = ["Date", "date", "Order_Date", "Sales_Date", "Transaction_Date"]
date_col = next((c for c in date_candidates if c in df.columns), None)
if date_col is None:
    raise ValueError(f"Could not find a date column. Available columns: {list(df.columns)}")

df[date_col] = pd.to_datetime(df[date_col], errors="coerce", dayfirst=False)
df = df.dropna(subset=[date_col]).drop_duplicates().copy()

# Find sales amount column; if absent, calculate it from quantity and unit price
sales_candidates = ["Total_Amount", "Total_Sales", "Sales", "Revenue", "Amount"]
sales_col = next((c for c in sales_candidates if c in df.columns), None)

if sales_col is not None:
    df[sales_col] = pd.to_numeric(df[sales_col], errors="coerce")
else:
    quantity_col = next((c for c in ["Quantity", "quantity", "Qty"] if c in df.columns), None)
    price_col = next((c for c in ["Price_per_Unit", "Price_per_unit", "Unit_Price", "Price"] if c in df.columns), None)
    if quantity_col and price_col:
        df[quantity_col] = pd.to_numeric(df[quantity_col], errors="coerce")
        df[price_col] = pd.to_numeric(df[price_col], errors="coerce")
        df["Total_Sales"] = df[quantity_col] * df[price_col]
        sales_col = "Total_Sales"
    else:
        raise ValueError(
            "Could not identify sales amount. Expected Total_Amount, Sales, Revenue, "
            "Amount, or both Quantity and Price_per_Unit."
        )

df = df.dropna(subset=[sales_col])
df = df[df[sales_col] >= 0].copy()
if df.empty:
    raise ValueError("No valid sales records remain after cleaning.")

# -------------------- 2. Prepare time-series data --------------------
# Monthly frequency is useful for viewing longer-term sales trends.
monthly = (
    df.set_index(date_col)[sales_col]
      .resample("MS")
      .sum()
      .asfreq("MS", fill_value=0)
)
monthly.index.name = "Date"
monthly_df = monthly.reset_index()
monthly_df.columns = ["Date", "Monthly_Sales"]
monthly_df["Year_Month"] = monthly_df["Date"].dt.to_period("M").astype(str)
monthly_df.to_csv(os.path.join(OUTPUT_DIR, "monthly_sales.csv"), index=False)

# Rolling average helps smooth short-term changes.
rolling = monthly.rolling(window=3, min_periods=1).mean()

# -------------------- 3. Forecast next six months --------------------
# Simple trend + month-of-year seasonal adjustment.
# This is a transparent baseline model for a student project.
y = monthly.to_numpy(dtype=float)
x = np.arange(len(y), dtype=float)

if len(y) >= 2:
    slope, intercept = np.polyfit(x, y, 1)
    trend_fitted = intercept + slope * x
else:
    slope, intercept = 0.0, float(y[0])
    trend_fitted = np.repeat(float(y[0]), len(y))

# Seasonal factors are estimated as average deviation from trend by calendar month.
residual = y - trend_fitted
month_numbers = monthly.index.month
seasonal_by_month = {}
for month_num in range(1, 13):
    values = residual[month_numbers == month_num]
    seasonal_by_month[month_num] = float(np.mean(values)) if len(values) else 0.0

future_dates = pd.date_range(
    monthly.index[-1] + pd.offsets.MonthBegin(1),
    periods=FORECAST_MONTHS,
    freq="MS"
)
future_x = np.arange(len(y), len(y) + FORECAST_MONTHS, dtype=float)
forecast_values = []
for i, dt in enumerate(future_dates):
    trend_value = intercept + slope * future_x[i]
    seasonal_value = seasonal_by_month.get(dt.month, 0.0)
    forecast_values.append(max(0.0, trend_value + seasonal_value))

forecast_df = pd.DataFrame({
    "Date": future_dates,
    "Forecast_Sales": np.round(forecast_values, 2)
})
forecast_df["Year_Month"] = forecast_df["Date"].dt.to_period("M").astype(str)
forecast_df.to_csv(os.path.join(OUTPUT_DIR, "sales_forecast_next_6_months.csv"), index=False)

# -------------------- 4. Visualization 1: Monthly sales trend --------------------
plt.figure(figsize=(10, 5))
plt.plot(monthly.index, monthly.values, marker="o", linewidth=1.5)
plt.title("Monthly Sales Trend")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "01_monthly_sales_trend.png"), dpi=160)
plt.close()

# -------------------- 5. Visualization 2: Monthly sales + 3-month rolling average --------------------
plt.figure(figsize=(10, 5))
plt.plot(monthly.index, monthly.values, marker="o", label="Monthly sales")
plt.plot(rolling.index, rolling.values, linewidth=2, label="3-month rolling average")
plt.title("Monthly Sales with Rolling Average")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "02_sales_rolling_average.png"), dpi=160)
plt.close()

# -------------------- 6. Visualization 3: Sales by category (if available) --------------------
category_col = next(
    (c for c in ["Product_Category", "Category", "Product category", "Product_Type"] if c in df.columns),
    None
)
if category_col:
    category_sales = df.groupby(category_col)[sales_col].sum().sort_values(ascending=False)
    category_sales.to_csv(os.path.join(OUTPUT_DIR, "sales_by_category.csv"), header=["Total_Sales"])
    plt.figure(figsize=(9, 5))
    category_sales.plot(kind="bar")
    plt.title("Total Sales by Product Category")
    plt.xlabel("Product Category")
    plt.ylabel("Total Sales")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, "03_sales_by_category.png"), dpi=160)
    plt.close()
else:
    print("No category column found; skipping category chart.")

# -------------------- 7. Visualization 4: Actual sales and forecast --------------------
plt.figure(figsize=(10, 5))
plt.plot(monthly.index, monthly.values, marker="o", label="Actual monthly sales")
plt.plot(future_dates, forecast_values, marker="o", linestyle="--", label="Forecast")
plt.axvline(monthly.index[-1], linestyle=":", linewidth=1)
plt.title("Sales Forecast for the Next 6 Months")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.legend()
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "04_sales_forecast.png"), dpi=160)
plt.close()

# -------------------- 8. Summary --------------------
summary = pd.DataFrame({
    "Metric": ["Number of records used", "First date", "Last date", "Total sales", "Average monthly sales"],
    "Value": [
        len(df),
        df[date_col].min().date().isoformat(),
        df[date_col].max().date().isoformat(),
        round(float(df[sales_col].sum()), 2),
        round(float(monthly.mean()), 2)
    ]
})
summary.to_csv(os.path.join(OUTPUT_DIR, "project_summary.csv"), index=False)

print("\nTask 3 completed successfully.")
print(f"Records used: {len(df)}")
print(f"Date range: {df[date_col].min().date()} to {df[date_col].max().date()}")
print(f"Total sales: {df[sales_col].sum():,.2f}")
print("\nFiles saved in:", OUTPUT_DIR)
print("- monthly_sales.csv")
print("- sales_forecast_next_6_months.csv")
print("- project_summary.csv")
print("- PNG visualization graphs")
print("\nNote: This is a simple baseline forecast. Evaluate it against a held-out period before using it for business decisions.")
