TASK 3: COMPLETE CODE WITH VISUALIZATION GRAPHS
Project: Sales Forecasting and Trend Analysis Using Time-Series Models

Files:
1. Task3_Sales_Forecasting_Visualization.py — full Python code
2. demo_retail_sales_dataset.csv — clearly marked DEMO data so the code can be tested immediately
3. requirements.txt — libraries needed

How to run:
1. Install Python 3.
2. Install packages: pip install -r requirements.txt
3. To use your actual data, put your selected dataset CSV in this folder and name it retail_sales_dataset.csv.
4. Run: python Task3_Sales_Forecasting_Visualization.py
5. Results are saved inside the task3_outputs folder.

Graphs produced:
- 01_monthly_sales_trend.png
- 02_sales_rolling_average.png
- 03_sales_by_category.png (if a category column is available)
- 04_sales_forecast.png

Data outputs:
- monthly_sales.csv
- sales_forecast_next_6_months.csv
- project_summary.csv
- sales_by_category.csv (if a category column is available)

Important:
The included CSV is synthetic demo data, not a real business dataset. It is included so you can test the code and see the graphs. For your final internship submission, replace it with the actual dataset selected for your project and rerun the program. Forecast values are a simple baseline estimate, not guaranteed future sales.
